<?php
/*
Plugin Name: WrapIt Custom Post Types
Plugin URI: http://demo.djmimi.net/themes/wrapit
Description: WrapIt Custom Post Types
Version: 1.0
Author: DJMiMi
Author URI: http://themeforest.net/user/djmimi
License: GNU General Public License version 3.0
*/
function wrapit_register_types(){
	register_post_type( 'slider', array(
		'labels' => array(
			'name' => __( 'Sliders', 'wrapit-cpt' ),
			'singular_name' => __( 'Slider', 'wrapit-cpt' )
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt',
		'has_archive' => false,
		'supports' => array(
			'title',
		)
	));

	$project_args = array(
		'labels' => array(
			'name' => __( 'Projects', 'wrapit-cpt' ),
			'singular_name' => __( 'Project', 'wrapit-cpt' )
		),
		'public' => true,
		'menu_icon' => 'dashicons-hammer',
		'has_archive' => true,
		'supports' => array(
			'title',
			'thumbnail',
			'editor',
			'excerpt'
		)
	);

	if( class_exists('ReduxFramework') && function_exists('wrapit_get_option') ){
		$project_slug = wrapit_get_option( 'project_slug' );
		if( !empty( $project_slug ) ){
			$project_args['rewrite'] = array( 'slug' => $project_slug );
		}
	}
	register_post_type( 'project', $project_args );


	
	$project_cat_args = array(
		'label' => __( 'Project Categories', 'wrapit' ),
		'hierarchical' => true,
		'labels' => array(
			'name' 							=> __( 'Project Categories', 'wrapit' ),
			'singular_name' 				=> __( 'Project Category', 'wrapit' ),
			'menu_name' 					=> __( 'Project Category', 'wrapit' ),
			'all_items'						=> __( 'All Project Categories', 'wrapit' ),
			'edit_item'						=> __( 'Edit Project Category', 'wrapit' ),
			'view_item'						=> __( 'View Project Category', 'wrapit' ),
			'update_item'					=> __( 'Update Project Category', 'wrapit' ),
			'add_new_item'					=> __( 'Add New Project Category', 'wrapit' ),
			'new_item_name'					=> __( 'New Project Category Name', 'wrapit' ),
			'parent_item'					=> __( 'Parent Project Category', 'wrapit' ),
			'parent_item_colon'				=> __( 'Parent Project Category:', 'wrapit' ),
			'search_items'					=> __( 'Search Project Categories', 'wrapit' ),
			'popular_items'					=> __( 'Popular Project Categories', 'wrapit' ),
			'separate_items_with_commas'	=> __( 'Separate project categories with commas', 'wrapit' ),
			'add_or_remove_items'			=> __( 'Add or remove project categories', 'wrapit' ),
			'choose_from_most_used'			=> __( 'Choose from the most used project categories', 'wrapit' ),
			'not_found'						=> __( 'No project categories found', 'wrapit' ),
		)
	
	);

	if( class_exists('ReduxFramework') && function_exists('wrapit_get_option') ){
		$project_cat_slug = wrapit_get_option( 'project_cat_slug' );
		if( !empty( $project_cat_slug ) ){
			$project_cat_args['rewrite'] = array( 'slug' => $project_cat_slug );
		}
	}
	register_taxonomy( 'project-cat', array( 'project' ), $project_cat_args );

}
add_action( 'init', 'wrapit_register_types' );

add_action( 'plugins_loaded', 'wrapit_plugin_domain' );
function wrapit_plugin_domain() {
  load_plugin_textdomain( 'wrapit-cpt', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
include( plugin_dir_path( __FILE__ ).'radium-one-click-demo-install/init.php' );
include( plugin_dir_path( __FILE__ ).'mailchimp.php' );
include( plugin_dir_path( __FILE__ ).'gallery.php' );
/* SHORTCODES */

/*
Send contact
*/
if( !function_exists('wrapit_send_contact') ){
function wrapit_send_contact(){
	$errors = array();
	$name = esc_sql( $_POST['name'] );	
	$email = esc_sql( $_POST['email'] );
	$subject = esc_sql( $_POST['subject'] );
	$message = esc_sql( $_POST['message'] );
	if( empty( $name ) || empty( $subject ) || empty( $email ) || empty( $message ) || empty( $_POST['captcha'] ) ){
		$response = array(
			'error' => esc_html__( 'All fields are required.', 'wrapit' ),
		);
	}
	else if( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
		$response = array(
			'error' => esc_html__( 'E-mail address is not valid.', 'wrapit' ),
		);	
	}
	else{
		$email_to = wrapit_get_option( 'contact_form_email' );
		$message = "
".esc_html__( 'Name: ', 'wrapit' )." {$name} \n			
".esc_html__( 'Email: ', 'wrapit' )." {$email} \n
".esc_html__( 'Message: ', 'wrapit' )."\n {$message} \n
		";
		$headers = array();
		$headers[] = 'Reply-To: '.$name.' <'.$email.'>';

		$info = @wp_mail( $email_to, $subject, $message, $headers );
		if( $info ){
			$response = array(
				'success' => esc_html__( 'Your message was successfully submitted.', 'wrapit' ),
			);
		}
		else{
			$response = array(
				'error' => esc_html__( 'Unexpected error while attempting to send e-mail.', 'wrapit' ),
			);
		}
		
	}
	
	echo json_encode( $response );
	die();	
}
add_action('wp_ajax_contact', 'wrapit_send_contact');
add_action('wp_ajax_nopriv_contact', 'wrapit_send_contact');
}
?>